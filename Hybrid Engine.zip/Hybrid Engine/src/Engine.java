import java.util.Vector;


public class Engine {
	//private boolean isStart = false;
	public static boolean isRunning = false;
	public static double mileage = 30.0;	//This is the default mileage value for plain roads. this value is in miles/gallon. eg 30.0 miles/gallon. 
	private double currentFuel = 0.00;
	//private double time = 0.0;
	Generator gen = new Generator();
		
	public boolean getEngineStatus()
	{
		return isRunning;
	}
	
	public void startEngine(FuelTank fuel, IntelligenceSystem is, Battery battery, Vector<String> results)
	{
		gen.chargeBattery(is, battery, results);
		System.out.println("Engine started....");
		results.add("Engine started....");
		
		if(isRunning)
		{
			System.out.println("Engine already running.");
			results.add("Engine already running.");
			return;
		}
		
		else if(is.getCurrentRoadCondition().equalsIgnoreCase("plain"))
		{
			isRunning = true;
			mileage = 30.0;
			currentFuel = ((is.getCurrentKm()/mileage)/FuelTank.capacity)*100;
			fuel.setFuelStatus(fuel.getFuelstatus(battery)-currentFuel);
			System.out.println("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
			results.add("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
		}
		
		else if(is.getCurrentRoadCondition().equalsIgnoreCase("uphill"))
		{
			isRunning = true;
			mileage = 15.0;
			currentFuel = ((is.getCurrentKm()/mileage)/FuelTank.capacity)*100;
			fuel.setFuelStatus(fuel.getFuelstatus(battery)-currentFuel);
			System.out.println("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
			results.add("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
		}
		
		else 
		{
			isRunning = true;
			mileage = 35.5;
			currentFuel = ((is.getCurrentKm()/mileage)/FuelTank.capacity)*100;
			fuel.setFuelStatus(fuel.getFuelstatus(battery)-currentFuel);
			System.out.println("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
			results.add("Fuel status : "+ (fuel.getFuelstatus(battery)-currentFuel));
		}
	}
	
	public void stopEngine(Vector<String> results)
	{
		isRunning = false;
		System.out.println("Engine stopped....");
		results.add("Engine stopped....");
	}
}
