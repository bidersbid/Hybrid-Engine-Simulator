import java.util.Vector;


public class VehicleModes {
	
	public static boolean electricMode = false;
	public static boolean cruiseMode = false;
	public static boolean overdriveMode = false;
	public static boolean powerboostMode = false;
	public static boolean negativesplitMode = false;
	
	Engine engine = new Engine();
	Motor motor = new Motor();
		
	public void startElectricMode(FuelTank fuel, Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		electricMode  = true;
		if(Engine.isRunning)
			engine.stopEngine(results);
		else if(Motor.isRunning)
		{
			System.out.println("Motor already running");
			results.add("Motor already running");
			return;
		}
		motor.startMotor(battery, is, modes, results);
	}
	
	public void stopElectricMode(Vector<String> results)
	{
		electricMode = false;
		System.out.println("Electric Mode stopped....");
		results.add("Electric Mode stopped....");
	}
	
	public void startCruiseMode(FuelTank fuel, Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		if(battery.getBatteryStatus() > 35 && fuel.getFuelstatus(battery) > 1)
		{
			motor.startMotor(battery, is, modes, results);
			engine.startEngine(fuel, is, battery, results);
			cruiseMode = true;
		}
		else if(battery.getBatteryStatus() <= 35 && fuel.getFuelstatus(battery) > 1)
		{
			motor.stopMotor(results);
			engine.startEngine(fuel, is, battery, results);
			cruiseMode = true;
		}
		else
		{
			System.out.println("Not Enough Fuel in the Tank and No Battery Power as well...!");
			results.add("Not Enough Fuel in the Tank and No Battery Power as well...!");
		}
	}
	
	public void stopCruiseMode(Vector<String> results)
	{
		cruiseMode = false;
		System.out.println("Cruize Mode stopped....");
		results.add("Cruize Mode stopped....");
	}
	
	public void startOverDriveMode(FuelTank fuel, Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		if(fuel.getFuelstatus(battery) > 1)
		{
			motor.stopMotor(results);
			overdriveMode = true;
			engine.startEngine(fuel, is, battery, results);
		}
	}
	
	public void stopOverDriveMode(Vector<String> results)
	{
		overdriveMode = false;
		System.out.println("Over drive Mode stopped....");
		results.add("Over drive Mode stopped....");
	}
	
	public void startPowerBoostMode(FuelTank fuel, Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		if(battery.getBatteryStatus() > 35 && fuel.getFuelstatus(battery) > 1)
		{
			motor.startMotor(battery, is, modes, results);
			engine.startEngine(fuel, is, battery, results);
			powerboostMode = true;
		}
	}
	
	public void stopPowerBoostMode(Vector<String> results)
	{
		powerboostMode = false;
		System.out.println("Power Boost Mode stopped....");
		results.add("Power Boost Mode stopped....");
	}
	
	public void startNegativeSplitMode(FuelTank fuel, Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		if(battery.getBatteryStatus() > 95 )
		{
			negativesplitMode = true;
			Engine.mileage = 50;	//we increase the mileage for the engine as the motor is helping to improve it.
			engine.startEngine(fuel, is, battery, results);
			motor.startMotor(battery, is, modes, results);
		}
	}
	
	public void stopNegativeSplitMode(Vector<String> results)
	{
		negativesplitMode = false;
		System.out.println("Negative Split Mode stopped....");
		results.add("Negative Split Mode stopped....");
	}

}
