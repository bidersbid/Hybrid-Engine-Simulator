import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Component;
import java.io.File;



@SuppressWarnings("serial")
public class StartSim extends JFrame {

	public JPanel contentPane2;
	private JPanel contentPane;
	private JTextField plainField;
	private JTextField uphillField;
	private JTextField downhillField;
	private JTextField enterWeight;
	private JTextField enterFuelLevel;
	private JTextField enterBatteryLevel;
	private JTextField enterAvgSpeed;
	
	public static Vector<String> road_type =  new Vector<String>();
    public static Vector<String> distance = new Vector<String>();
    
    double weight;
	double FuelLevel;
	double BatteryLevel;
	double AvgSpeed;
	private JTextPane displayDistance;
	
	static int flag = 1;
	
	public static void SplashScreen()
    {
        Icon icn = new ImageIcon("loading.gif");
        JWindow jwin = new JWindow();
        try 
        {
            jwin.getContentPane()
            .add(
                new JLabel(icn,SwingConstants.CENTER));                
            jwin.setBounds(100, 100, 400, 300);
            jwin.setLocationRelativeTo(null);
            jwin.setVisible(true);
                      
            File soundFile = new File("start.wav");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
            Thread.sleep(5000);          
        } 
        catch (Exception e) 
        {
          System.out.println(e.getMessage());
        }

        jwin.setVisible(false);
        jwin.dispose();
    }
	
	public static void main(String[] args) {SplashScreen();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					StartSim frame = new StartSim();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public StartSim() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setAutoscrolls(true);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblHybridVehicleSimulation = new JLabel("Hybrid Vehicle Simulation");
		lblHybridVehicleSimulation.setFont(new Font("Tempus Sans ITC", Font.BOLD, 16));
		lblHybridVehicleSimulation.setHorizontalAlignment(SwingConstants.CENTER);
		lblHybridVehicleSimulation.setBounds(400, 25, 211, 38);
		contentPane.add(lblHybridVehicleSimulation);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1008, 21);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnNewMenu.add(mntmExit);
		
		mntmExit.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e2) {
			System.exit(0);
				
			}
			
		});
		
		JLabel labelselect = new JLabel("Selection Mades");
		labelselect.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		labelselect.setBounds(734, 130, 150, 15);
		contentPane.add(labelselect);
		
		JLabel lblRoadCondition = new JLabel("Road Conditions");
		lblRoadCondition.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblRoadCondition.setBounds(100, 130, 150, 15);
		contentPane.add(lblRoadCondition);
		
		JLabel label = new JLabel("Distance (miles)");
		label.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		label.setBounds(328, 130, 150, 15);
		contentPane.add(label);
		
		
		final JRadioButton plain = new JRadioButton("Plain");
		plain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(plain.isSelected()){
					plainField.setVisible(true);
					uphillField.setVisible(false);
					downhillField.setVisible(false);
				}
			}
		});
		plain.setBounds(100, 175, 150, 20);
		contentPane.add(plain);
		
		final JRadioButton uphill = new JRadioButton("Uphill");
		uphill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(uphill.isSelected()){
					plainField.setVisible(false);
					uphillField.setVisible(true);
					downhillField.setVisible(false);
				}
			}
		});
		uphill.setBounds(100, 225, 150, 20);
		contentPane.add(uphill);
		
		final JRadioButton downhill = new JRadioButton("Downhill");
		downhill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(downhill.isSelected()){
					plainField.setVisible(false);
					uphillField.setVisible(false);
					downhillField.setVisible(true);
				}
			}
		});
		
		downhill.setBounds(100, 275, 150, 20);
		contentPane.add(downhill);
		
		final ButtonGroup group = new ButtonGroup();
		group.add(plain);
		group.add(uphill);
		group.add(downhill);
		
		
		plainField = new JTextField();
		plainField.setBounds(330, 175, 100, 20);
		contentPane.add(plainField);
		plainField.setColumns(10);
		plainField.setVisible(false);
		plainField.setText("");
		
				
		uphillField = new JTextField();
		uphillField.setBounds(330, 225, 100, 20);
		contentPane.add(uphillField);
		uphillField.setColumns(10);
		uphillField.setVisible(false);
		uphillField.setText("");
		
		downhillField = new JTextField();
		downhillField.setBounds(330, 275, 100, 20);
		contentPane.add(downhillField);
		downhillField.setColumns(10);
		downhillField.setVisible(false);
		downhillField.setText("");
				
		
		JLabel labelWeight = new JLabel("Passenger Weights(in lbs) ");
		labelWeight.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		labelWeight.setBounds(100, 350, 200, 15);
		contentPane.add(labelWeight);
		
		enterWeight = new JTextField();
		enterWeight.setBounds(330, 350, 100, 20);
		contentPane.add(enterWeight);
		enterWeight.setColumns(10);
		
		JLabel labelFuelLevel = new JLabel("Fuel Level (in %)");
		labelFuelLevel.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		labelFuelLevel.setBounds(100, 400, 200, 15);
		contentPane.add(labelFuelLevel);
		
		enterFuelLevel = new JTextField();
		enterFuelLevel.setColumns(10);
		enterFuelLevel.setBounds(330, 398, 100, 20);
		contentPane.add(enterFuelLevel);
				
		JLabel labelBatteryLevel = new JLabel("Battery Level(in %)");
		labelBatteryLevel.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		labelBatteryLevel.setBounds(100, 452, 200, 15);
		contentPane.add(labelBatteryLevel);
				
		enterBatteryLevel = new JTextField();
		enterBatteryLevel.setColumns(10);
		enterBatteryLevel.setBounds(330, 450, 100, 20);
		contentPane.add(enterBatteryLevel);
		
		JLabel labelAvgSpeed = new JLabel("Average Speed(in miles)");
		labelAvgSpeed.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		labelAvgSpeed.setBounds(100, 500, 200, 15);
		contentPane.add(labelAvgSpeed);
		
		enterAvgSpeed = new JTextField();
		enterAvgSpeed.setColumns(10);
		enterAvgSpeed.setBounds(330, 498, 100, 20);
		contentPane.add(enterAvgSpeed);
		
		//submit button
		JButton submit = new JButton("Start Simulation");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					flag = 1;
					weight = (double)(Double.parseDouble(enterWeight.getText()));
					FuelLevel = (double)(Double.parseDouble(enterFuelLevel.getText()));
					BatteryLevel = (double) (Double.parseDouble(enterBatteryLevel.getText()));
					AvgSpeed = (double) (Double.parseDouble(enterAvgSpeed.getText()));
					}
					catch(Exception e1){
						flag = 0;
						JOptionPane.showMessageDialog(null, "Please fill in all fields.");
					}
					
					
					int typeSize = road_type.size();
					int distanceSize = distance.size();
						
					String roadType[] = new String[typeSize];
					String milesArr[] = new String[distanceSize];
									
					road_type.copyInto(roadType);
					distance.copyInto(milesArr);
	
/*====================================================================================================*/
					
					
/*******************************************************************************************************/
					//defining a vector to output the results.
					Vector<String> results = new Vector<String>();
					
					GPS gps = new GPS();
					Battery battery = new Battery();
					FuelTank fuel = new FuelTank();
					IntelligenceSystem is = new IntelligenceSystem();
					
					System.out.println("Starting the Simulator....!");
					results.add("Starting the Simulator....!");
					
					double[] miles = new double[typeSize];
					
					for(int i=0; i<typeSize; i++)
					{
						miles[i] = Double.parseDouble(milesArr[i]);
					}
							
					battery.setBatteryStatus(BatteryLevel);
					fuel.setFuelStatus(FuelLevel);
					
					double initialFuel = fuel.getFuelstatus(battery);
					
					gps.setRoute(typeSize, miles, roadType, results);
					
					is.setAvgSpeed(AvgSpeed);
					
					for(int i=0; i<typeSize; i++)
					{
						//new IntelligenceSystem(gps, battery, fuel);
						System.out.println("\n---------------------------------------------------------------\n");
						results.add("\n---------------------------------------------------------------\n");
						
						System.out.println("Initial stats for Road Type: "+ roadType[i]);
						results.add("Initial stats for Road Type:"+ roadType[i]);
						
						System.out.println("Initial Battery : "+ battery.getBatteryStatus());
						results.add("Initial Battery : "+ battery.getBatteryStatus());
						
						System.out.println("Initial Fuel : "+ fuel.getFuelstatus(battery));
						results.add("Initial Fuel : "+ fuel.getFuelstatus(battery));
						
						is.startIntelligenceSystem(gps, battery, fuel, is, results);
					}
					
					System.out.println("------------------------------------------------------");
					results.add("------------------------------------------------------");
					System.out.println("Simulation Ended Successfully.");
					results.add("Simulation Ended Successfully.");
					System.out.println("------------------------------------------------------");
					results.add("------------------------------------------------------");
					System.out.println("Results of the simulation are :");
					results.add("Results of the simulation are :");
					System.out.println("Fuel Left : " + fuel.getFuelstatus(battery));
					results.add("Fuel Left : " + fuel.getFuelstatus(battery));
					System.out.println("Battery left : " +battery.getBatteryStatus());
					results.add("Battery left : " +battery.getBatteryStatus());
					
					double finalKm = 0.0;
					for(int i=0; i< typeSize; i++)
						finalKm = finalKm + miles[i];
					double finalMileage =  (finalKm/(((initialFuel - fuel.getFuelstatus(battery))*FuelTank.capacity)/100));
					
					System.out.println("Total Miles travelled : "+finalKm);
					results.add("Total Miles travelled : "+finalKm);
					System.out.println("Final Average Mileage for the selected trip : "+ finalMileage);
					results.add("Final Average Mileage for the selected trip : "+ finalMileage);
					
/*******************************************************************************************************/	
					//System.out.println(+flag);
					if(flag == 1)
					{
						contentPane.setVisible(false);
						setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						setBounds(100, 100, 1024, 768);						
						contentPane2 = new JPanel();
						contentPane2.setBackground(Color.WHITE);
						contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));
						setContentPane(contentPane2);
						contentPane2.setLayout(null);
						
						JMenuBar opmenu = new JMenuBar();
						contentPane2.add(opmenu);
						opmenu.setVisible(true);
						opmenu.setBounds(0,0,1024, 20);
						
						JMenu filemenu = new JMenu("File");
						opmenu.add(filemenu);
						
						JMenuItem item1 = new JMenuItem("Exit");
						filemenu.add(item1);
						
						item1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent ee)
							{
								System.exit(0);
							}
						});
						
						JTextPane textPane = new JTextPane();
						JScrollPane scroll = new JScrollPane(textPane);
						textPane.setBackground(Color.YELLOW);
						scroll.setBounds(108, 81, 795, 546);
						contentPane2.add(scroll);
						
						JLabel headLabel = new JLabel("Simulation Results");
						headLabel.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
						headLabel.setHorizontalAlignment(SwingConstants.CENTER);
						headLabel.setBounds(180, 20, 700, 25);
						contentPane2.add(headLabel);
						
						StringBuilder res = new StringBuilder();
						for(String res1 : results){
							res.append(res1)
								.append(System.getProperty("line.separator"));}
						textPane.setText(res.toString());
				}
					
			}
		});
		submit.setBounds(330, 600, 150, 25);
		contentPane.add(submit);
		
		
		
		displayDistance = new JTextPane();
		JScrollPane scrolldisplayDistance = new JScrollPane(displayDistance);
		scrolldisplayDistance.setBounds(829, 175, 40, 120);
		contentPane.add(scrolldisplayDistance);
		scrolldisplayDistance.setViewportView(displayDistance);
		displayDistance.setAlignmentY(Component.TOP_ALIGNMENT);
		displayDistance.setAlignmentX(Component.LEFT_ALIGNMENT);
		displayDistance.setText(" ");
		displayDistance.setBackground(Color.YELLOW);
		
		final JTextPane displayRoadType = new JTextPane();
		JScrollPane scrolldisplayRoadType= new JScrollPane(displayRoadType);
		scrolldisplayRoadType.setBounds(734, 175, 85, 120);
		contentPane.add(scrolldisplayRoadType);
		displayRoadType.setAlignmentY(Component.TOP_ALIGNMENT);
		displayRoadType.setAlignmentX(Component.LEFT_ALIGNMENT);
		displayRoadType.setText(" ");
		displayRoadType.setBackground(Color.YELLOW);
		
		//go button
		JButton button = new JButton(">>");
				
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if ((plain.isSelected()) && (!plainField.getText().isEmpty())){
					
					road_type.addElement("Plain");
					String miles = plainField.getText();
					distance.addElement(miles);
				}
				
				
				else if((uphill.isSelected()) && (!uphillField.getText().isEmpty())){
					road_type.addElement("Uphill");
					String miles = uphillField.getText();
					distance.addElement(miles);
				}
				else if((downhill.isSelected()) && (!downhillField.getText().isEmpty())){
					road_type.addElement("Downhill");
					String miles = downhillField.getText();
					distance.addElement(miles);
				}
				else
					JOptionPane.showMessageDialog(null,"Please enter all fields. ");
			
				
				
				StringBuilder rt = new StringBuilder();
				for(String roadtype : road_type){
					rt.append(roadtype)
						.append(System.getProperty("line.separator"));
											
				}
				displayRoadType.setText(rt.toString());
				
				StringBuilder d = new StringBuilder();
				for(String dis : distance){
					d.append(dis)
						.append(System.getProperty("line.separator"));
											
				}
				displayDistance.setText(d.toString());
				
				plainField.setText("");
				uphillField.setText("");
				downhillField.setText("");
				group.clearSelection();			
				
				
			}
			
			
		});
		
		button.setBounds(547, 223, 100, 25);
		contentPane.add(button);
		
		//clear button
		JButton clear = new JButton("CLEAR");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				road_type.clear();
				distance.clear();
				plainField.setText("");
				uphillField.setText("");
				downhillField.setText("");
				enterWeight.setText("");
				enterFuelLevel.setText("");
				enterBatteryLevel.setText("");
				enterAvgSpeed.setText("");
				displayRoadType.setText ("");
				displayDistance.setText ("");
				group.clearSelection();
			}
		});
		clear.setBounds(547, 601, 100, 25);
		contentPane.add(clear);
	}
}
