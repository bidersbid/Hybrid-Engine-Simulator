import java.util.Vector;


public class Motor {
	public static boolean isRunning = false; 
	
	public boolean getMotorStatus()
	{
		return isRunning;
	}
	
	public void startMotor(Battery battery, IntelligenceSystem is, VehicleModes modes, Vector<String> results)
	{
		System.out.println("Motor started ....");
		results.add("Motor started ....");
		
		if(isRunning)
		{
			System.out.println("Motor Already Running!");
			results.add("Motor Already Running!");
			return;
		}
		
		battery.batteryDischarge(modes, is);
	}
	
	public void stopMotor(Vector<String> results)
	{
		isRunning = false;
		System.out.println("Motor stopped...");
		results.add("Motor stopped...");
	}
	
}
