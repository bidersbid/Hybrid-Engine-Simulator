import java.util.Vector;


public class Generator {
	private double currentBatteryStatus;
	public double chargeTime = 0.0;
	
	public void chargeBattery(IntelligenceSystem is, Battery battery, Vector<String> results)
	{
		if(Engine.isRunning)
		{
			System.out.println("Generator started...");
			results.add("Generator started...");
			
			chargeTime = ((is.getCurrentKm()/IntelligenceSystem.avgSpeed)/3)*100;
			currentBatteryStatus = battery.getBatteryStatus()+chargeTime;
			if(currentBatteryStatus > 100)
				currentBatteryStatus = 100;
			battery.setBatteryStatus(currentBatteryStatus);
			System.out.println("Battery status : " + currentBatteryStatus);
			results.add("Battery status : " + currentBatteryStatus);
		}
	}
}
