
public class Weight {
	private int weight = 0;	//this parameter is defined in terms of kg's. eg by default its 0 kg.
	public int getWeight()
	{
		return weight;
	}
	public void setAllWeights(int VehicleWeight, int DriverWeight, int PassengerWeight, int ExtraWeight)
	{
		weight = VehicleWeight + DriverWeight + PassengerWeight + ExtraWeight;
	}
}
