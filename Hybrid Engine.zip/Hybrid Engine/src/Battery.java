
public class Battery {
	private double batteryLevel = 0.00;	//This variable is described in percentage. eg 0% by default.
	private double milesOnBattery = 0.0;
	private double dischargeTime = 0.0;
	
	public double getBatteryStatus()
	{
		return batteryLevel;
	}
	
	public void setBatteryStatus(double chargeTime)
	{
		batteryLevel = chargeTime;
	}
	
	public void batteryDischarge(VehicleModes modes, IntelligenceSystem is)
	{
		if(modes.electricMode)
		{
			milesOnBattery = is.getCurrentKm();
			dischargeTime = milesOnBattery/IntelligenceSystem.avgSpeed;
			batteryLevel = batteryLevel - (dischargeTime * 100);
			if(batteryLevel < 0)
				batteryLevel = 30;
		}
	}
}
