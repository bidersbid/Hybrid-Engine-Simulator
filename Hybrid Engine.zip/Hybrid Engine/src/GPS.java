import java.util.Vector;


public class GPS {
	private double[] km;
	private String route[];
	int counterRt = -1;	//this variable is set to -1 on purpose. Because we need to increment it everytime the method getRouteCondition is called & for the first call to start at 0;
	int counterKm = -1;
	private int NumberOfElements;
	
	public GPS(){}
	public void setRoute(int size, double[] UserInputKm, String[] UserInputRoute, Vector<String> results)
	{
		System.out.println("Setting the Route For the Simulation..!");
		results.add("Setting the Route For the Simulation..!");
		km = new double[size];
		route = new String[size];
		NumberOfElements = size;
		
		//storing the route info here in km and route variable. These data are captured from the UserInterface class.
		for(int i=0; i<size; i++)
		{
			km[i] = UserInputKm[i];
			route[i] = UserInputRoute[i];
			//System.out.println("At GPS2: "+ route[i]);
		}
		
	}
	
	public String getRouteCondition(Vector<String> results)
	{
		counterRt++;
		
		if(counterRt>NumberOfElements)
		{
			System.out.println("Too many calls to getRoute(): no more routes available! Now Exiting..");
			results.add("Too many calls to getRoute(): no more routes available! Now Exiting..");
			return "end";	//This is the marker to specify end of the content.
		}
		return route[counterRt];
	}
	
	public double getKm(Vector<String> results)
	{
		counterKm++;
		if(counterKm>NumberOfElements)
		{
			System.out.println("Too many calls to getKm(): no more routes available! Now Exiting..");
			results.add("Too many calls to getKm(): no more routes available! Now Exiting..");
			return 0.0;
		}
		return km[counterKm];
	}
}
