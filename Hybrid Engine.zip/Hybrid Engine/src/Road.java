
public class Road {
	private String condition = "Plain";	//this variable is set to road conditions. eg plain, upwards, downwards. By default its set to Plain.
	
	public String getCondition()
	{
		return condition;
	}
	
	public void setRoadCondition(String newCondition)
	{
		condition = newCondition;
	}
	 
}
