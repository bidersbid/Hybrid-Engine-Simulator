import java.util.Vector;


public class IntelligenceSystem {
	private double fuelLevel;
	private double batteryLevel;
	private String currentRoadCondition;
	private double currentKm = 0.0;
	public static double avgSpeed = 50.0; //miles/hr.
	VehicleModes modes =new VehicleModes();
			
	public IntelligenceSystem(){}
	
	public void setAvgSpeed(double speed)
	{
		avgSpeed = speed;
	}
	
	public void startIntelligenceSystem(GPS gps, Battery battery, FuelTank fuel, IntelligenceSystem is, Vector<String> results)	//carrying the Fuel and Battery objects here.
	{
		fuelLevel = fuel.getFuelstatus(battery);
		batteryLevel =  battery.getBatteryStatus();
		currentRoadCondition = gps.getRouteCondition(results);
		currentKm = gps.getKm(results);
		
		System.out.println("Average speed Selected : " + avgSpeed);
		results.add("Average speed Selected : " + avgSpeed);
		
		System.out.println("Current Road Type : "+currentRoadCondition);
		results.add("Current Road Type : "+currentRoadCondition);
		
		System.out.println("Current Road Type length : "+currentKm);
		results.add("Current Road Type length : "+currentKm);
		
		if(currentRoadCondition.equalsIgnoreCase("plain") && batteryLevel > 95)
		{
			modes.startNegativeSplitMode(fuel, battery, is, modes, results);
			
			System.out.println("Vehicle Mode: Negative Split Mode");
			results.add("Vehicle Mode: Negative Split Mode");
			
			stopAllModes(results);
		}
		else if(currentRoadCondition.equalsIgnoreCase("downhill"))
		{
			modes.startOverDriveMode(fuel, battery, is, modes, results);
			
			System.out.println("Vehicle Mode: Over Drive Mode");
			results.add("Vehicle Mode: Over Drive Mode");
			
			stopAllModes(results);
		}
		else if(currentRoadCondition.equalsIgnoreCase("plain") && batteryLevel > 35)
		{
			modes.startCruiseMode(fuel, battery, is, modes, results);
			
			System.out.println("Vehicle Mode: cruise Mode");
			results.add("Vehicle Mode: cruise Mode");
			
			stopAllModes(results);
		} 
		else if(batteryLevel > 40 || fuelLevel <= 1)
		{
			modes.startElectricMode(fuel, battery, is, modes, results);
			
			System.out.println("Vehicle Mode: Electric Mode");
			results.add("Vehicle Mode: Electric Mode");
			
			stopAllModes(results);
		}
		else if(currentRoadCondition.equalsIgnoreCase("uphill"))
		{
			modes.startPowerBoostMode(fuel, battery, is, modes, results);
			
			System.out.println("Vehicle Mode: Power Bost Mode");
			results.add("Vehicle Mode: Power Bost Mode");
			
			stopAllModes(results);
		}
		else 
		{
				System.out.println("Battery Low....Starting Engine Only!");
				results.add("Battery Low....Starting Engine Only!");
				
				modes.startOverDriveMode(fuel, battery, is, modes, results);
				
				System.out.println("Vehicle Mode: Over Drive Mode");
				results.add("Vehicle Mode: Over Drive Mode");
		}
	}
	
	public String getCurrentRoadCondition()
	{
		return currentRoadCondition;
	}
	
	public double getCurrentKm()
	{
		return currentKm;
	}
	
	public void stopAllModes(Vector<String> results)
	{
		if(VehicleModes.cruiseMode)
			modes.stopCruiseMode(results);
		else if(VehicleModes.electricMode)
			modes.stopElectricMode(results);
		else if(VehicleModes.overdriveMode)
			modes.stopOverDriveMode(results);
		else if(VehicleModes.powerboostMode)
			modes.stopPowerBoostMode(results);
		else
			modes.stopNegativeSplitMode(results);
	}
}
