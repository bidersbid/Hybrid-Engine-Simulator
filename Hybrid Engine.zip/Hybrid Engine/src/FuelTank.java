import javax.swing.JOptionPane;


public class FuelTank {
	private double fuelLevel = 0.00;	//this variable is described in percentage.eg 0% by default.
	public static double capacity = 12;	//this states the capacity of the fuel tank in gallons.
	
	public double getFuelstatus(Battery battery)
	{
		if(fuelLevel <= 0 && battery.getBatteryStatus() < 30)
		{
			String st = JOptionPane.showInputDialog("Fuel Empty!!!..Enter New Amount(in %)", fuelLevel);
			fuelLevel = Double.parseDouble(st);
		}
		return fuelLevel;
	}
	public void setFuelStatus(double newfuelLevel)
	{
		fuelLevel = newfuelLevel;
	}
	public void fillFuel(double amount)	//here amount is also described in percentage.
	{
		fuelLevel = fuelLevel + amount;
	}
}
